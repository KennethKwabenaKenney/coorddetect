from .core import detect_xyz, detect_xyz_batch

__all__ = ["detect_xyz", "detect_xyz_batch"]

__version__ = "0.1.0"
